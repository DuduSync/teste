function formatDateTime(date) {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${day}/${month} ${hours}:${minutes}:${seconds}`;
}

function formatTime(ms) {
    const hours = Math.floor(ms / 3600000).toString().padStart(2, '0');
    const minutes = Math.floor((ms % 3600000) / 60000).toString().padStart(2, '0');
    const seconds = Math.floor((ms % 60000) / 1000).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

const vehicleTimers = {};
const archivedVehicles = [];

function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.style.display = 'none';
    });

    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }

    if (sectionId === 'finished') {
        updateFinalizedSubmenu();
        document.getElementById('finalizedSubmenu').style.display = 'block';
    } else {
        document.getElementById('finalizedSubmenu').style.display = 'none';
    }
}

function updateFinalizedSubmenu() {
    fetch('/api/vehicles')
        .then(response => response.json())
        .then(vehicles => {
            const finalizedVehicles = vehicles.filter(vehicle => vehicle.finalizado && !vehicle.arquivado);
            const totalValue = finalizedVehicles.reduce((sum, vehicle) => sum + vehicle.valor_total, 0);
            const washedCars = finalizedVehicles.filter(vehicle => vehicle.tipo_lavagem !== "Nenhuma").length;
            const parkedCars = finalizedVehicles.filter(vehicle => vehicle.tipo_lavagem === "Nenhuma").length;
            const totalCars = finalizedVehicles.length;

            document.getElementById('totalValue').innerText = totalValue.toFixed(2);
            document.getElementById('washedCars').innerText = washedCars;
            document.getElementById('parkedCars').innerText = parkedCars;
            document.getElementById('totalCars').innerText = totalCars;

            const vehicleContainer = document.getElementById('vehicleContainer');
            vehicleContainer.innerHTML = '';
            finalizedVehicles.forEach(vehicle => {
                const vehicleCard = document.createElement('div');
                vehicleCard.className = 'vehicle-card';
                vehicleCard.id = `vehicle-${vehicle.placa}`;
                vehicleCard.innerHTML = `
                    <p><strong>Nome do Carro:</strong> ${vehicle.nome}</p>
                    <p><strong>Placa:</strong> ${vehicle.placa}</p>
                    <p><strong>Telefone:</strong> ${vehicle.telefone}</p>
                    <p><strong>Lavagem:</strong> ${vehicle.tipo_lavagem}</p>
                    <p><strong>Data:</strong> ${vehicle.data}</p>
                    <p><strong>Entrada:</strong> ${vehicle.entrada}</p>
                    <p><strong>Saída:</strong> ${vehicle.saida}</p>
                    <p><strong>Tempo Total:</strong> ${vehicle.tempo_total}</p>
                    <p><strong>Valor:</strong> R$ ${vehicle.valor_total.toFixed(2)}</p>
                `;
                vehicleContainer.appendChild(vehicleCard);
            });
        })
        .catch(error => console.error('Erro ao carregar veículos finalizados:', error));
}

function archiveVehicle(plate) {
    fetch(`/api/vehicles/${plate}/archive`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then((response) => response.json())
        .then(() => {
            setTimeout(() => {
                loadFinishedVehicles();
                updateFinalizedSubmenu();
            }, 100);
        })
        .catch((error) => console.error('Erro ao arquivar veículo:', error));
}

function loadInProgressVehicles() {
    fetch('/api/vehicles')
        .then(response => response.json())
        .then(vehicles => {
            const vehicleCards = document.getElementById('vehicleCards');
            if (vehicleCards) {
                vehicleCards.innerHTML = '';
                vehicles.forEach(vehicle => {
                    if (!vehicle.finalizado) {
                        const card = document.createElement('div');
                        card.className = 'card';
                        card.innerHTML = `
                            <h3>${vehicle.nome}</h3>
                            <p><strong>Nome do Carro:</strong> ${vehicle.nome_carro || 'N/A'}</p>
                            <p><strong>Placa:</strong> ${vehicle.placa}</p> <!-- Usando o ID agora -->
                            <p><strong>Chave</strong> ${vehicle.chave}</p>
                            <p><strong>Lavagem:</strong> ${vehicle.tipo_lavagem}</p>
                            <p><strong>Entrada:</strong> ${vehicle.entrada}</p>
                            <p id="timer-${vehicle.id}"><strong>Tempo:</strong> 00:00:00</p> <!-- Usando o ID para o timer -->
                            <p id="cost-${vehicle.id}" style="font-weight: bold; font-size: 110%;">
                                <strong style="color: white;">Valor:</strong> 
                                <span style="color: #27ae60;">R$ ${vehicle.valor_total.toFixed(2)}</span>
                            </p>
							<p><strong>ID:</strong> ${vehicle.id}</p> <!-- Usando o ID agora -->
                            <button class="finalize-button" onclick="finalizeVehicle('${vehicle.id}')">Finalizar</button> <!-- Usando o ID -->
                            <button class="sendWhatsAppInfo" onclick="sendWhatsAppInfo('${vehicle.id}')">Informações</button> <!-- Usando o ID -->
                            <button class="sendWhatsAppWash" onclick="sendWhatsAppWash('${vehicle.id}')">Completa</button> <!-- Usando o ID -->
                        `;
                        vehicleCards.prepend(card);
                        if (!vehicleTimers[vehicle.id]) {  // Usando o ID
                            const entryTime = parseEntryTime(vehicle.entrada);
                            startTimer(`timer-${vehicle.id}`, entryTime, vehicle.id, vehicle.tipo_lavagem); // Usando o ID
                        }
                    }
                });
            }
        })
        .catch(error => console.error('Erro ao carregar veículos em andamento:', error));
}



function startTimer(timerId, entryTime, vehicleId, washType) {
    // Se já existir um timer, limpa ele usando o vehicleId
    if (vehicleTimers[vehicleId]) {
        clearInterval(vehicleTimers[vehicleId]);
    }

    // Converte a hora de entrada para o formato de data
    const entryDateTime = new Date(entryTime);

    // Cria um novo timer para o veículo, utilizando o ID
    vehicleTimers[vehicleId] = setInterval(() => {
        const currentTime = new Date();
        const timeOccupied = currentTime - entryDateTime;  // Calcula o tempo ocupado desde a entrada
        const timerElement = document.getElementById(timerId);  // Usando o ID do veículo

        if (timerElement) {
            // Atualiza o cronômetro na página em tempo real
            timerElement.innerHTML = `<strong>Tempo:</strong> ${formatTime(timeOccupied)}`;
        }

        const costElement = document.getElementById(`cost-${vehicleId}`);  // Usando o ID para calcular o custo
        if (costElement) {
            const updatedCost = calculateRealTimeCost(timeOccupied, washType);  // Calcula o custo com base no tempo
            costElement.innerHTML = `
                <strong style="color: white;">Valor:</strong> 
                <span style="color: #27ae60;">R$ ${updatedCost.toFixed(2)}</span>
            `;
        }
    }, 250);  // Atualiza a cada 1 segundo
}




function calculateRealTimeCost(ms, washType) {
    const firstHourRate = 12;
    const additionalHourRate = 5;
    const halfHourRate = 8;
    const freeHoursForWash = 3;
    const washExtraHourRate = 12;
    const washingPrices = {
        Nenhuma: 0,
		Ducha: 25,
        PqSCera: 50,
        PqCCera: 70,
		GdSCera: 60,
		GdCCera: 80,
        Caminhonete: 80,
        CaminhoneteECaçamba: 90,
        Uber: 45
    };

    const totalHours = ms / 3600000;
    let parkingCost = 0;

    if (washType !== "Nenhuma") {
        if (totalHours <= freeHoursForWash) {
            parkingCost = washingPrices[washType] || 0;
        } else {
            const extraHours = Math.ceil(totalHours - freeHoursForWash);
            parkingCost = washingPrices[washType] + (extraHours * washExtraHourRate);
        }
    } else {
        if (totalHours <= 0.5) {
            parkingCost = halfHourRate;
        } else if (totalHours <= 1) {
            parkingCost = firstHourRate;
        } else {
            parkingCost = firstHourRate + Math.ceil(totalHours - 1) * additionalHourRate;
        }
    }

    return parkingCost;
}



function loadFinishedVehicles() {
    fetch('/api/vehicles')
        .then((response) => response.json())
        .then((vehicles) => {
            const finishedCards = document.getElementById('finishedCards');
            if (finishedCards) {
                finishedCards.innerHTML = ''; // Limpa os veículos existentes
                vehicles.forEach((vehicle) => {
                    if (vehicle.finalizado && !vehicle.arquivado) {
                        const card = document.createElement('div');
                        card.className = 'card';
                        card.innerHTML = `
                            <h3>${vehicle.nome}</h3>
                            <p><strong>Nome do Carro:</strong> ${vehicle.nome_carro || 'N/A'}</p>
                            <p><strong>Placa:</strong> ${vehicle.placa}</p>
                            <p><strong>Chave</strong> ${vehicle.chave}</p>
                            <p><strong>Telefone:</strong> ${vehicle.telefone || 'N/A'}</p>
                            <p><strong>Lavagem:</strong> ${vehicle.tipo_lavagem}</p>
                            <p><strong>Data:</strong> ${vehicle.data}</p>
                            <p><strong>Entrada:</strong> ${vehicle.entrada}</p>
                            <p><strong>Saída:</strong> ${vehicle.saida}</p>
                            <p><strong>Tempo Total:</strong> ${vehicle.tempo_total || 'N/A'}</p>
                            <p id="cost-${vehicle.placa}" style="font-weight: bold; font-size: 110%; color: white;">
                                <strong>Valor:</strong> <span style="color: #27ae60;">R$ ${vehicle.valor_total.toFixed(2)}</span>
                            </p>
                            <button class="finalize-button" onclick="archiveVehicle('${vehicle.placa}')">Arquivar</button>
                            <label for="adicional-${vehicle.placa}">Adicional:</label>
                            <input type="number" id="adicional-${vehicle.placa}" name="adicional" step="1" value="0">
                            <button class="set-adicional" onclick="calcularAdicional('${vehicle.placa}')">Calcular adicional</button>
                        `;
                        finishedCards.appendChild(card);
                    }
                });
            }
        })
        .catch((error) => console.error('Erro ao carregar veículos finalizados:', error));
}


function archiveVehicle(plate) {
    fetch(`/api/vehicles/${plate}/archive`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erro ao arquivar: ${response.status} - ${response.statusText}`);
            }
            return response.json();
        })
        .then(vehicle => {
            if (vehicle.arquivado) {
                console.log(`Veículo com placa ${plate} arquivado com sucesso.`);
                
                // Atualiza as listas de veículos
                loadFinishedVehicles(); // Atualiza a lista de veículos finalizados
                loadArchivedVehicles(); // Atualiza a lista de veículos arquivados (se esta função existir)
                
                // Atualiza o submenu com os dados mais recentes
                return fetch('/api/vehicles')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`Erro ao buscar veículos: ${response.status} - ${response.statusText}`);
                        }
                        return response.json();
                    })
                    .then(vehicles => {
                        updateFinalizedSubmenu(vehicles); // Atualiza o submenu
                        console.log('Submenu atualizado com sucesso.');
                    });
            } else {
                console.error(`Erro: Veículo com placa ${plate} não foi arquivado corretamente.`);
            }
        })
        .catch(error => console.error('Erro ao arquivar veículo:', error));
}





function loadArchivedVehicles() {
    fetch('/api/vehicles') // Faz uma requisição para obter os veículos
        .then(response => response.json())
        .then(vehicles => {
            const archivedSection = document.getElementById('archivedCards');
            if (archivedSection) {
                archivedSection.innerHTML = ''; // Limpa a seção de veículos arquivados
                vehicles.forEach(vehicle => {
                    if (vehicle.arquivado) { // Filtra somente os veículos arquivados
                        const card = document.createElement('div');
                        card.className = 'card archived'; // Adiciona uma classe para estilos
                        card.innerHTML = `
                            <h3>${vehicle.nome}</h3>
                            <p><strong>Nome do Carro:</strong> ${vehicle.nome_carro || 'N/A'}</p>
                            <p><strong>Placa:</strong> ${vehicle.placa}</p>
                            <p><strong>Chave</strong> ${vehicle.chave}</p>
                            <p><strong>Telefone:</strong> ${vehicle.telefone || 'N/A'}</p>
                            <p><strong>Lavagem:</strong> ${vehicle.tipo_lavagem}</p>
                            <p><strong>Data:</strong> ${vehicle.data}</p>
                            <p><strong>Entrada:</strong> ${vehicle.entrada}</p>
                            <p><strong>Saída:</strong> ${vehicle.saida || 'N/A'}</p>
                            <p id="cost-${vehicle.placa}" style="font-weight: bold; font-size: 110%; color: white;">
                                <strong>Valor:</strong> <span style="color: #27ae60;">R$ ${vehicle.valor_total.toFixed(2)}</span>
                            </p>
                        `;
                        archivedSection.appendChild(card); // Adiciona o cartão ao DOM
                    }
                });

                // Caso não existam veículos arquivados, exibe uma mensagem
                if (archivedSection.innerHTML === '') {
                    archivedSection.innerHTML = '<p>Nenhum veículo arquivado.</p>';
                }
            }
        })
        .catch(error => console.error('Erro ao carregar veículos arquivados:', error));
}


function parseEntryTime(entry) {
    const parts = entry.split(':');
    if (parts.length === 3) {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate(), parts[0], parts[1], parts[2]);
    }
    return null;
}

document.getElementById('vehicleForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const ownerInput = document.getElementById('nome');
    const plateInput = document.getElementById('placa');
    const additionalInput = document.getElementById('adicional');  // Adicionando o campo adicional

    const formattedName = ownerInput.value
        .toLowerCase()
        .replace(/\b\w/g, letter => letter.toUpperCase());
    const formattedPlate = plateInput.value.toUpperCase();

    ownerInput.value = formattedName;
    plateInput.value = formattedPlate;

    const newVehicle = {
        nome: formattedName,
        telefone: document.getElementById('telefone').value,
        nome_carro: document.getElementById('nome_carro').value || 'N/A',
        placa: formattedPlate,
        tipo_lavagem: document.getElementById('tipo_lavagem').value || "Nenhuma",
        entrada: new Date().toLocaleTimeString(),
        valor_total: 0,
        finalizado: false
    };

    // Envia os dados para o backend
    fetch('/api/vehicles', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newVehicle)
    })
    .then(response => response.json())
    .then(() => {
        document.getElementById('vehicleForm').reset();
        loadInProgressVehicles();
    })
    .catch(error => console.error('Erro ao adicionar veículo:', error));
});



function finalizeVehicle(vehicleId) {
    if (!vehicleId) {
        console.error('ID não encontrado!');
        return;
    }

    const timerElement = document.getElementById(`timer-${vehicleId}`);
    const totalTime = timerElement ? timerElement.textContent.split('Tempo: ')[1] : '00:00:00';
    const costElement = document.getElementById(`cost-${vehicleId}`);
    const totalCost = costElement ? parseFloat(costElement.textContent.split('R$ ')[1]) : 0;
    const currentTime = new Date().toLocaleTimeString();

    // First request without confirmation
    fetch(`/api/vehicles/${vehicleId}/finalize`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            confirmation: false
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.needsConfirmation) {
            if (confirm(data.message)) {
                // Send second request with confirmation
                fetch(`/api/vehicles/${vehicleId}/finalize`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        confirmation: true,
                        saida: currentTime,
                        tempo_total: totalTime,
                        valor_total: totalCost
                    })
                })
                .then(response => response.json())
                .then(result => {
                    clearInterval(vehicleTimers[vehicleId]);
                    delete vehicleTimers[vehicleId];
                    loadInProgressVehicles();
                    loadFinishedVehicles();
                })
                .catch(error => console.error('Erro na finalização:', error));
            }
        }
    })
    .catch(error => console.error('Erro na confirmação:', error));
}












async function sendWhatsAppInfo(vehicleId) {
    try {
        const response = await fetch('/api/vehicles');
        if (!response.ok) {
            throw new Error('Erro ao carregar os veículos');
        }

        const vehicles = await response.json();

        // Verifica se o vehicleId e o vehicle.id são válidos antes de usar toLowerCase
        const vehicle = vehicles.find(v => v.id && vehicleId && v.id.toLowerCase() === vehicleId.toLowerCase());

        if (!vehicle || !vehicle.telefone) {
            alert('Veículo ou telefone não encontrado.');
            return;
        }

        const message = `
 *Olá, ${vehicle.nome}!*  
Seu veículo de placa *${vehicle.placa}* está sob os cuidados da *Sky Center!*   
Agradecemos imensamente a sua preferência!   

Informações:
- *Hora de Entrada:* ${vehicle.entrada}
- *Lavagem:* ${vehicle.tipo_lavagem}

 *Tabela de Valores*:  
- *R$ 8,00* - Até *30 minutos*  
- *R$ 12,00* - *1ª Hora*  
- *R$ 5,00* - Por *hora adicional*  

 *Informações importantes*:  
 Veículos lavados têm direito a *3 horas de tolerância apartir da hora de entrada* no estacionamento.  
 *Avisaremos por aqui assim que a lavagem estiver concluída!*   
 *Recomendamos retirar o veículo o mais rápido possível após a conclusão da lavagem,* pois após as 3 horas de tolerância, o valor de estacionamento começará a ser cobrado normalmente. 

*Horario de funcionamento: 08:00 - 18:00*

*Sky Center* deseja um excelente dia!  
 Seu carro está em boas mãos. 
`;

        window.open(`https://wa.me/55${vehicle.telefone}?text=${encodeURIComponent(message)}`, '_blank');
    } catch (error) {
        console.error('Erro ao enviar mensagem pelo WhatsApp:', error);
        alert('Erro ao tentar enviar a mensagem. Verifique o console para mais detalhes.');
    }
}

async function sendWhatsAppWash(vehicleId) {
    try {
        const response = await fetch('/api/vehicles');
        if (!response.ok) {
            throw new Error('Erro ao carregar os veículos');
        }

        const vehicles = await response.json();

        // Verifica se o vehicleId e o vehicle.id são válidos antes de usar toLowerCase
        const vehicle = vehicles.find(v => v.id && vehicleId && v.id.toLowerCase() === vehicleId.toLowerCase());

        if (!vehicle || !vehicle.telefone) {
            alert('Veículo ou telefone não encontrado.');
            return;
        }

        const message = `
Olá, *${vehicle.nome}!*

Seu veículo de placa *${vehicle.placa}* já *foi lavado* com todo o cuidado e está pronto para retirada.

Lembre-se: veículos lavados têm *3 horas de tolerância* a partir da hora de entrada no estacionamento. Após esse período, será cobrada a estadia conforme nossa tabela de valores.

Agradecemos por confiar na Sky Center para cuidar do seu carro. Nossa equipe trabalhou para garantir que ele ficasse impecável, refletindo a qualidade que você merece.

Recomendamos retirar o veículo o quanto antes para evitar *custos adicionais.*

*Horario de funcionamento: 08:00 - 18:00*

Agradecemos sua preferência e desejamos um excelente dia!  
Atenciosamente,  
Equipe Sky Center
`;

        window.open(`https://wa.me/55${vehicle.telefone}?text=${encodeURIComponent(message)}`, '_blank');
    } catch (error) {
        console.error('Erro ao enviar mensagem pelo WhatsApp:', error);
        alert('Erro ao tentar enviar a mensagem. Verifique o console para mais detalhes.');
    }
}










// Função para atualizar o valor adicional e o valor total
function atualizarValorAdicional(placa, adicional) {
    const veiculo = veiculosFinalizados.find(v => v.placa === placa);
    if (veiculo) {
        const valorAtual = parseFloat(veiculo.valor.replace('R$ ', '').replace(',', '.'));
        const valorAdicional = parseFloat(adicional);

        // Atualiza o valor total
        const novoValor = (valorAtual + valorAdicional).toFixed(2);
        veiculo.valor = `R$ ${novoValor.replace('.', ',')}`;

        // Salva no JSON atualizado
        salvarNoJSON();

        // Atualiza a interface
        exibirVeiculosFinalizados();
		
        loadFinishedVehicles();
        updateFinalizedSubmenu();
    }
}

// Função para salvar as mudanças no arquivo JSON
function salvarNoJSON() {
    fetch('veiculos.json', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ finalizados: veiculosFinalizados })
    }).then(response => {
        if (!response.ok) {
            console.error('Erro ao salvar o JSON');
			loadFinishedVehicles();
            updateFinalizedSubmenu();
        }
    });
}

// Adicionando o evento no botão "Calcular adicional"
document.querySelectorAll('.set-adicional').forEach((botao) => {
    botao.addEventListener('click', () => {
        const campo = botao.previousElementSibling; // Assumindo que o campo adicional está antes do botão
        const placa = campo.dataset.placa;
        const adicional = campo.value;
        atualizarValorAdicional(placa, adicional);
		loadFinishedVehicles(placa, total);
        updateFinalizedSubmenu(placa, total);
    });
});



function calcularAdicional(placa) {
    const adicionalInput = document.getElementById(`adicional-${placa}`);
    const adicional = parseFloat(adicionalInput.value);

    if (!isNaN(adicional)) {
        // Atualize o valor no servidor
        fetch(`/api/vehicles/${placa}/update`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ adicional: adicional }),
        })
        .then(response => response.json())
        .then(() => {
            // Após a atualização, recarregue todos os veículos finalizados
            loadFinishedVehicles();  // Esta função recarrega os veículos finalizados na interface
        })
        .catch((error) => console.error('Erro ao atualizar o valor adicional:', error));
    } else {
        alert("Por favor, insira um valor válido.");
    }
}


document.addEventListener('DOMContentLoaded', () => {
    showSection('addVehicle');
    loadInProgressVehicles();
    loadFinishedVehicles();
    loadArchivedVehicles();
});


function toggleSubmenu() {
    const submenu = document.getElementById("finalizedSubmenu");
    const icon = document.getElementById("icon");
    const finishedSection = document.getElementById("finished");

    // Verifica se a seção "Finalizados" está visível
    if (finishedSection.style.display !== "none") {
        // Alterna entre mostrar e esconder o submenu e o botão
        if (submenu.classList.contains("minimized")) {
            submenu.classList.remove("minimized");  // Exibe o submenu
            icon.textContent = "-";  // Altera o ícone para "-"
        } else {
            submenu.classList.add("minimized");  // Minimiza o submenu
            icon.textContent = "+";  // Altera o ícone para "+"
        }
    }
}

document.getElementById('placa').addEventListener('input', function() {
    const placa = this.value.toUpperCase().replace(/\s/g, ''); // Remove espaços e coloca em maiúsculas
    let placaFormatada = placa;

    // Primeiro tenta buscar sem espaço
    fetch(`/api/vehicles/${placaFormatada}`)
        .then(response => response.json())
        .then(vehicle => {
            if (vehicle) {
                // Preenche os campos do formulário com as informações do veículo
                document.getElementById('nome').value = vehicle.nome || '';
                document.getElementById('telefone').value = vehicle.telefone || '';
                document.getElementById('nome_carro').value = vehicle.nome_carro || '';
                document.getElementById('tipo_lavagem').value = 'Nenhuma'; // ou o valor desejado
            } else {
                // Caso não encontre, tenta buscar com o espaço após os 3 primeiros caracteres
                placaFormatada = placa.slice(0, 3) + ' ' + placa.slice(3); // Adiciona o espaço
                fetch(`/api/vehicles/${placaFormatada}`)
                    .then(response => response.json())
                    .then(vehicle => {
                        if (vehicle) {
                            // Preenche os campos com as informações da placa formatada
                            document.getElementById('nome').value = vehicle.nome || '';
                            document.getElementById('telefone').value = vehicle.telefone || '';
                            document.getElementById('nome_carro').value = vehicle.nome_carro || '';
                            document.getElementById('tipo_lavagem').value = 'Nenhuma'; // ou o valor desejado
                        } else {
                            alert('Veículo não encontrado.');
                        }
                    })
                    .catch(error => console.error('Erro ao buscar o veículo com o espaço:', error));
            }
        })
        .catch(error => {
            console.error('Erro ao buscar o veículo:', error);
        });
});

const sectionsContainer = document.querySelector('.sections-container');
const sections = document.querySelectorAll('.section');
const tabs = document.querySelectorAll('.tab');
let currentIndex = 0;

// Função para ativar a seção
function setActiveSection(index) {
    sections.forEach((section, i) => {
        section.classList.remove('active');
        if (i === index) {
            section.classList.add('active');
        }
    });

    // Atualizando as abas para indicar qual está ativa
    tabs.forEach((tab, i) => {
        if (i === index) {
            tab.style.backgroundColor = '#2ecc71'; // Cor de fundo ativa
        } else {
            tab.style.backgroundColor = '#34495e'; // Cor de fundo inativa
        }
    });
}

// Função para mudar de aba ao clicar
tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => {
        currentIndex = index;
        sectionsContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
        setActiveSection(currentIndex);
    });
});

// Detectar o gesto de deslizar
let startX = 0;
let endX = 0;

sectionsContainer.addEventListener('touchstart', (e) => {
    startX = e.changedTouches[0].screenX;
});

sectionsContainer.addEventListener('touchend', (e) => {
    endX = e.changedTouches[0].screenX;
    if (startX > endX + 50) { // Arrastou para a esquerda
        changeSection('next');
    } else if (startX < endX - 50) { // Arrastou para a direita
        changeSection('prev');
    }
});

// Função para mudar de seção por gestos
function changeSection(direction) {
    if (direction === 'next' && currentIndex < sections.length - 1) {
        currentIndex++;
    } else if (direction === 'prev' && currentIndex > 0) {
        currentIndex--;
    }

    sectionsContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
    setActiveSection(currentIndex);
}

// Inicializando a seção ativa
setActiveSection(currentIndex);
